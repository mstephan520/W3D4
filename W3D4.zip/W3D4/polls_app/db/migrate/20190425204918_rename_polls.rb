class RenamePolls < ActiveRecord::Migration[5.2]
  def change
    add_column :polls, :title, :string, null: false
    add_column :polls, :user_id, :integer, null: false
    add_column :polls, :timestamps, :timestamp
  end
end
