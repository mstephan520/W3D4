# == Schema Information
#
# Table name: polls
#
#  id         :bigint(8)        not null, primary key
#  title      :string           not null
#  user_id    :integer          not null
#  timestamps :datetime
#

class Poll < ApplicationRecord
    
    validates :title, :user_id, presence: true
    
    belongs_to :author,
        class_name: :User,
        primary_key: :id,
        foreign_key: :user_id

    has_many :questions,
        class_name: :Question,
        primary_key: :id,
        foreign_key: :poll_id
        

end
