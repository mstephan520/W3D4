# == Schema Information
#
# Table name: questions
#
#  id         :bigint(8)        not null, primary key
#  poll_id    :integer          not null
#  text       :string           not null
#  timestamps :datetime
#

class Question < ApplicationRecord

    validates :poll_id, :text, presence: true

    has_many :answer_choices,
        class_name: :AnswerChoice, 
        primary_key: :id,
        foreign_key: :question_id

    belongs_to :poll,  
        class_name: :Poll,
        primary_key: :id,
        foreign_key: :poll_id

end
